package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.Cart;
import com.example.demo.model.Photos;
import com.example.demo.model.PhotosRepository;
import com.example.demo.service.CartService;

import jakarta.servlet.http.HttpSession;

@Controller
public class CartController {
	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private PhotosRepository photoRepo;
	
	@GetMapping("/cart/add")
	public String addToCart(HttpSession httpSession, @RequestParam Integer photoId,Model model) {
		
		Integer loginUserId = (Integer) httpSession.getAttribute("loginUserId");
		
		if(loginUserId == null) {
			model.addAttribute("loginReq", "請先登入");
			return "users/loginPage";
		}
		
		cartService.addToCart(loginUserId, photoId);
		
		model.addAttribute("addToCartOk", "已新增到購物車");
		
		List<Photos> photoList = photoRepo.findAll();
		
		model.addAttribute("photoList", photoList);
		
		return "photos/showPhotosPage";
	}
	
	@GetMapping("/cart/list")
	public String shoppingCart(HttpSession httpSession, Model model) {
		
		Integer loginUserId = (Integer) httpSession.getAttribute("loginUserId");
		
		if(loginUserId != null) {
			List<Cart> cartList = cartService.usersCart(loginUserId);
			model.addAttribute("cartList", cartList);
			return "cart/listPage";
		}
		
		return "users/loginPage";
		
	}
	
	@GetMapping("/cart/addOne")
	public String addOneVol(HttpSession httpSession, @RequestParam Integer photosId, Model model) {
		
		Integer loginUserId = (Integer) httpSession.getAttribute("loginUserId");
		
		cartService.addOneVol(loginUserId, photosId);
		
		List<Cart> cartList = cartService.usersCart(loginUserId);
		model.addAttribute("cartList", cartList);
		
		return "cart/listPage";
	}
	
	@GetMapping("/cart/minusOne")
	public String minusOne(HttpSession httpSession, @RequestParam Integer photosId, Model model) {
		Integer loginUserId = (Integer) httpSession.getAttribute("loginUserId");
		
		cartService.minusOneVol(loginUserId, photosId);
		
		List<Cart> cartList = cartService.usersCart(loginUserId);
		model.addAttribute("cartList", cartList);
		
		return "cart/listPage";
	}

}
