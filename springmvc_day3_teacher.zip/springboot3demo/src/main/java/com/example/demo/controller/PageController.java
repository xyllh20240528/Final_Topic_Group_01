package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.service.ImageGeneratorService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

@Controller
public class PageController {
	
	@Autowired
	private ImageGeneratorService imgService;
	
	@GetMapping("/")
	public String index() {
		return "index";
	}
	
	@GetMapping("/aabout")
	public String about() {
		return "aboutPage";
	}
	
	@GetMapping("/image/playground")
	public String imagePlayground() {
		return "aiPlay/fun";
	}
	
	@PostMapping("/image/gene")
	public String geneImage(@RequestParam String prompt, Model model) throws JSONException, JsonMappingException, JsonProcessingException {
		String result = imgService.generateImage(prompt);
		
		model.addAttribute("result", result);
		
		return "aiPlay/fun";
	}

}
