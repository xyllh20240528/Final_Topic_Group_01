package com.example.demo.controller;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.model.Photos;
import com.example.demo.model.PhotosRepository;

@Controller
public class PhotosController {
	
	@Autowired
	private PhotosRepository photosRepo;

	@GetMapping("/photos/upload")
	public String photoUpload() {
		return "photos/uploadPage";
	}
	
	@PostMapping("/photos/uploadPost")
	public String uploadPost(@RequestParam String name, @RequestParam MultipartFile file,Model model) throws IOException {
		
		Photos photos = new Photos();
		
		photos.setName(name);
		
		photos.setPhotoFile(file.getBytes());
		
		photosRepo.save(photos);
		
		model.addAttribute("okMsg", "上傳OK");
		
		return "photos/uploadPage";
	}
	
	@GetMapping("/photos/download")
	public ResponseEntity<byte[]> download(@RequestParam Integer id){
		Optional<Photos> optional = photosRepo.findById(id);
		
		if(optional.isPresent()) {
			Photos photos = optional.get();
			
			byte[] photoFile = photos.getPhotoFile();
			
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.IMAGE_JPEG);
			
			                                 // 回應的資料, header, status code
			return new ResponseEntity<byte[]>(photoFile, headers, HttpStatus.OK);
		}
		                               // 單純回傳 404
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@GetMapping("/photos/list")
	public String listPhotos(Model model) {
		
		List<Photos> photos = photosRepo.findAll();
		
		model.addAttribute("photoList", photos);
		
		return "photos/showPhotosPage";
	}
	
}
