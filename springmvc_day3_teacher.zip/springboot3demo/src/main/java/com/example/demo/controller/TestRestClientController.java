package com.example.demo.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClient;

@RestController
public class TestRestClientController {
	
	@GetMapping("/testapi/1")
	public String testRestClient() {
		RestClient restclient = RestClient.create();
		
		String result = restclient.get()
	    .uri("https://jsonplaceholder.typicode.com/posts/1")
	    .accept(MediaType.APPLICATION_JSON)
	    .retrieve() // 取得
	    .body(String.class); // http response body
		
		return result;
	}
	
	

}
