package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.Users;
import com.example.demo.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UsersController {
	
	@Autowired
	private UserService userService;
	
	@GetMapping("/users/register")
	public String register() {
		return "/users/registerPage";
	}
	
	@PostMapping("/users/registerPost")
    public String registerPost(
    		@RequestParam("username") String username, 
    		@RequestParam("pwd") String pwd,
    		Model model) {
		
		boolean result = userService.checkUserNameIfExist(username);
		
		if(!result) {
			userService.resgister(username, pwd);
			model.addAttribute("okMsg", "註冊成功");	
		}else {
			model.addAttribute("errorMsg", "註冊失敗，已經有此帳號");		
		}
		
		return "/users/registerPage";
		
	}
	
	
	@GetMapping("/users/login")
	public String login() {
		return "/users/loginPage";
	}
	
	@PostMapping("/users/loginPost")
	public String loginPost(String username, String pwd, HttpSession httpSession,Model model) {
		Users result = userService.checkLogin(username, pwd);
		
		if(result != null) {
			model.addAttribute("okMsg", "登入成功");
			httpSession.setAttribute("loginUsername", result.getUsername());
			httpSession.setAttribute("loginUserId", result.getId());
		}else {
			model.addAttribute("errorMsg", "登入失敗，請重新輸入");
		}
		
		return "/users/loginPage";	
	}
	
	@GetMapping("/users/logout")
	public String logout(HttpSession httpSession) {
		
		// 1.
//		httpSession.removeAttribute("loginUsername");
//		httpSession.removeAttribute("loginUserId");
		
		// 2.
		httpSession.invalidate();
		
		return "redirect:/";
	}
	
}
