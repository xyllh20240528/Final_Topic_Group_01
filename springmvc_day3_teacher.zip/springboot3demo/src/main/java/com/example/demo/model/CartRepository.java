package com.example.demo.model;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CartRepository extends JpaRepository<Cart, CartId> {

	@Query("from Cart c where c.cartId.usersId = :uuu and c.cartId.photosId = :ppp")
	Cart findByUsersIdAndPhotosId(@Param("uuu") Integer usersId,@Param("ppp") Integer photosId);
	
	@Query("from Cart c where c.users.id = :uid")
	List<Cart> findCartByUsersId(@Param("uid") Integer userId);
	
	List<Cart> findByUsers(Users users);
	
	List<Cart> findByUsersId(Integer usersId);
}
