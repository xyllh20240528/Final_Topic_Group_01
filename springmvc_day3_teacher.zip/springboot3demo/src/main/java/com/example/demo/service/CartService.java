package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Cart;
import com.example.demo.model.CartId;
import com.example.demo.model.CartRepository;
import com.example.demo.model.Photos;
import com.example.demo.model.PhotosRepository;
import com.example.demo.model.Users;
import com.example.demo.model.UsersRepository;

@Service
public class CartService {
	
	@Autowired
	private UsersRepository usersRepo;
	
	@Autowired
	private PhotosRepository photosRepo;
	
	@Autowired
	private CartRepository cartRepo;
	
	@Transactional
	public Cart addToCart(Integer userId, Integer photoId) {
		
		// 判斷有沒有已經在資料庫內
		Cart dbCart = cartRepo.findByUsersIdAndPhotosId(userId, photoId);
		
		if(dbCart != null) {
			dbCart.setVol(dbCart.getVol() + 1);
			return dbCart;
		}
		
		Optional<Users> optional = usersRepo.findById(userId);
		Users users = optional.get();
		
		Optional<Photos> optional2 = photosRepo.findById(photoId);
		Photos photos = optional2.get();
		
		CartId cartId = new CartId();
		cartId.setUsersId(userId);
		cartId.setPhotosId(photoId);
		
		Cart cart = new Cart();
		cart.setCartId(cartId);
		cart.setUsers(users);
		cart.setPhotos(photos);
		cart.setVol(1);
		
		return cartRepo.save(cart);
		
	}
	
	public List<Cart> usersCart(Integer userId){
		return cartRepo.findByUsersId(userId);
	}
	
	@Transactional
	public Cart addOneVol(Integer usersId, Integer photosId) {
		Cart dbCart = cartRepo.findByUsersIdAndPhotosId(usersId, photosId);
		
		dbCart.setVol(dbCart.getVol() + 1);
		
		return dbCart;
	}
	
	@Transactional
	public Cart minusOneVol(Integer usersId, Integer photosId) {
		Cart dbCart = cartRepo.findByUsersIdAndPhotosId(usersId, photosId);
		
		if(dbCart.getVol() == 1) {
			cartRepo.delete(dbCart);
		}else {
			dbCart.setVol(dbCart.getVol() -1);
		}	
		
		return dbCart;
	}

}
