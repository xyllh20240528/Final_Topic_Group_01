package com.example.demo.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ImageGeneratorService {
	
	@Value("${openai.apikey}")
	private String apiKey;
	
	public String generateImage(String prompt) throws JSONException, JsonMappingException, JsonProcessingException {
		
		RestClient restclient = RestClient.create();
		
		// 協助物件轉JSON
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("prompt", prompt);
		jsonObject.put("n", 1);
		jsonObject.put("size", "256x256");
		
		// Java 物件轉 JSON 字串
		String jsonString = jsonObject.toString();
		
		String result = restclient.post()
		.uri("https://api.openai.com/v1/images/generations")
		.contentType(MediaType.APPLICATION_JSON)
		.header("Authorization", "Bearer " + apiKey)
		.body(jsonString)
		.retrieve()
		.body(String.class);
		
		// 將JSON字串轉換為 Java 物件的工具
		ObjectMapper objectMapper = new ObjectMapper();
		
		JsonNode jsonNode = objectMapper.readTree(result);
		
		String imageUrl = jsonNode.path("data").get(0).path("url").asText();
		
		
		return imageUrl;
	}

}
