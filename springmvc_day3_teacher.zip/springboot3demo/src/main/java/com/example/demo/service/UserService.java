package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.model.Users;
import com.example.demo.model.UsersRepository;

@Service
public class UserService {

	@Autowired
	private PasswordEncoder pwdEncoder;

	@Autowired
	private UsersRepository userRepo;

	public boolean checkUserNameIfExist(String username) {
		Users dbUser = userRepo.findByUsername(username);

		if (dbUser != null) {
			return true;
		}

		return false;
	}

	public Users resgister(String username, String pwd) {
		String encodedPwd = pwdEncoder.encode(pwd);

		Users users = new Users();
		users.setUsername(username);
		users.setPwd(encodedPwd);

		return userRepo.save(users);
	}

	public Users checkLogin(String loginUsername, String loginPwd) {
		Users dbUser = userRepo.findByUsername(loginUsername);

		if (dbUser != null) {
			String encodedPassword = dbUser.getPwd();
			boolean result = pwdEncoder.matches(loginPwd, encodedPassword);
		
			if (result) {		
			   return dbUser;
			}	
		}
		return null;
	}
	
	public Users findUsersByName(String username) {
		return userRepo.findByUsername(username);
	}
}
